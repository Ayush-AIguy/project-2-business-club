import React from 'react';
import { Bot, Video, Podcast } from 'lucide-react';
import '../styles/animations.css';

export default function About() {
  const activities = [
    {
      icon: <Bot className="h-8 w-8 text-blue-600" />,
      title: "AI Projects",
      description: "Learn to build AI tools and chatbots using platforms like Voiceflow and Python."
    },
    {
      icon: <Video className="h-8 w-8 text-blue-600" />,
      title: "Media Production",
      description: "Join our social media and video editing team to create impactful content."
    },
    {
      icon: <Podcast className="h-8 w-8 text-blue-600" />,
      title: "Podcast - Triomphant",
      description: "Be part of our YouTube podcast series featuring notable individuals from Lebanon Trail High School."
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4 animate-float">About Us</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            The AI Business Club focuses on developing AI-powered solutions and integrating AI into real-world business settings.
            Our projects span customer support automation, business innovations, and creative media outreach.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {activities.map((activity, index) => (
            <div 
              key={index} 
              className="p-6 border border-gray-200 rounded-lg hover-scale hover-glow"
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="mb-4 animate-float">{activity.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{activity.title}</h3>
              <p className="text-gray-600">{activity.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}