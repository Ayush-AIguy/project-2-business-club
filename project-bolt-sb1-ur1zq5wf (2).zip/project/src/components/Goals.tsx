import React from 'react';
import { Target, Users, Lightbulb } from 'lucide-react';

export default function Goals() {
  const goals = [
    {
      icon: <Target className="h-12 w-12 text-blue-600" />,
      title: "Enhance AI Understanding",
      description: "Develop a deep understanding of AI in business applications through hands-on projects and workshops."
    },
    {
      icon: <Lightbulb className="h-12 w-12 text-blue-600" />,
      title: "Foster Innovation",
      description: "Create and implement real-world AI projects that solve business challenges."
    },
    {
      icon: <Users className="h-12 w-12 text-blue-600" />,
      title: "Build Community",
      description: "Promote collaboration through media production and community engagement initiatives."
    }
  ];

  return (
    <section id="goals" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-16 animate-float">Club Goals</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {goals.map((goal, index) => (
            <div 
              key={index} 
              className="text-center p-6 rounded-lg hover-scale hover-glow"
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="flex justify-center mb-4 animate-float">
                {goal.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{goal.title}</h3>
              <p className="text-gray-600">{goal.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}