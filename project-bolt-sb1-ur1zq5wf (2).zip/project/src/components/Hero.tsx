import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 animate-gradient min-h-[100dvh] flex items-center">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1677442136019-21780ecad995"
          alt="AI Background"
          className="w-full h-full object-cover opacity-20"
        />
      </div>
      <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20 md:pt-0">
        <div className="max-w-3xl mx-auto">
          <h1 
            className="text-3xl md:text-6xl font-bold text-white mb-6 animate-typewriter px-2"
            style={{ '--duration': '3000ms' } as React.CSSProperties}
          >
            Welcome to AI Business Club
          </h1>
          <p className="text-lg md:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto animate-float px-2">
            Explore the exciting world of artificial intelligence and its practical applications in business.
            No prior experience needed – we'll teach you everything you need to know!
          </p>
          <a
            href="#join"
            className="inline-flex items-center px-6 py-3 md:px-8 md:py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-blue-50 hover-glow hover-slide"
          >
            Join AI Business Club Today!
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>
    </div>
  );
}