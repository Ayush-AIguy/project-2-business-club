import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Goals from './components/Goals';
import Services from './components/Services/Services';
import Leadership from './components/Leadership';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import CursorGlow from './components/CursorGlow';
import Chatbot from './components/Chatbot';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <CursorGlow />
      <Chatbot />
      <Navbar />
      <Hero />
      <About />
      <Goals />
      <Services />
      <Leadership />
      <FAQ />
      <Contact />
    </div>
  );
}